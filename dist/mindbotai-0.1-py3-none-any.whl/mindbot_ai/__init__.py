# mindbot_ai/__init__.py
from .ai import configure_ai, generate_content
