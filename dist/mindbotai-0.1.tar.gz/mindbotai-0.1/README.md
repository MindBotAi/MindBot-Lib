
### **How to Install MindBot Ai:**

After you have all the files ready, you can install the library locally by following these steps:

1. Run the following command to install your library:
   ```bash
   pip install .
